# resq_sim – RESQ-Sense tracked rover in Gazebo + ROS 2

Targets **ROS 2 Jazzy + Gazebo Harmonic (gz-sim 8) on Ubuntu 24.04** (the officially paired combination).
Humble / Ubuntu 22.04 also works – see "Other versions" at the bottom.

## 1. Install (Ubuntu 24.04, native, dual boot, VM or WSL2 with WSLg)

```bash
# ROS 2 Jazzy (follow docs.ros.org/en/jazzy/Installation if not installed yet)
sudo apt update
sudo apt install -y ros-jazzy-desktop ros-jazzy-ros-gz python3-colcon-common-extensions python3-scipy
```
`ros-jazzy-ros-gz` pulls in Gazebo Harmonic, `ros_gz_sim` and `ros_gz_bridge`.

## 2. Build

```bash
mkdir -p ~/resq_ws/src && cp -r resq_sim ~/resq_ws/src/     # or unzip the workspace
cd ~/resq_ws
source /opt/ros/jazzy/setup.bash
colcon build --symlink-install
source install/setup.bash
```

## 3. Run

```bash
ros2 launch resq_sim sim.launch.py                    # rubble course + RViz
ros2 launch resq_sim sim.launch.py world:=flat_test   # flat floor with 1 m markers (for calibration)
ros2 launch resq_sim sim.launch.py gui:=false rviz:=false      # headless
ros2 launch resq_sim sim.launch.py track_shell:=false # hide the solid belt so you can see the wheels turn
```

Drive (new terminal, `source ~/resq_ws/install/setup.bash`):

```bash
ros2 run resq_sim rover_keyboard          # w/s/a/d drive, x stop, r/f lift arms down/up, t rest
# or any Twist publisher:
ros2 topic pub -r 10 /cmd_vel geometry_msgs/msg/Twist "{linear: {x: 0.2}, angular: {z: 0.0}}"
# lift arms (0 = as in CAD, 1.75 rad = pointing down; positive pushes the ground):
ros2 topic pub --once /lift/cmd_pos std_msgs/msg/Float64 "{data: 1.2}"
```

## 4. Topics

| ROS topic | type | notes |
|---|---|---|
| `/cmd_vel` | Twist (in) | skid-steer drive |
| `/lift/cmd_pos` | Float64 (in) | both lift arms (rad) |
| `/odom`, TF `odom→base_link` | Odometry | from wheel velocities (drifts under slip, like the real robot) |
| `/ground_truth/odom` | Odometry | simulator pose, for evaluating your SLAM/fusion |
| `/imu/data` | Imu | 100 Hz with MPU6050-like noise |
| `/camera/image_raw`, `/camera/camera_info` | Image / CameraInfo | 640x480 @15 Hz, on the lens position of your CAD |
| `/joint_states` | JointState | wheels + lift arms |
| `/clock` | Clock | everything runs on sim time |

Check what Gazebo really publishes with `gz topic -l`; the ROS⇄Gazebo name map is `config/bridge.yaml`.

## 5. Calibrate skid-steer turning (do this once)

Tracks scrub when they turn, so the *effective* track separation is larger than the geometric 0.192 m.

```bash
ros2 launch resq_sim sim.launch.py world:=flat_test
ros2 run resq_sim calibrate_turn
```
It prints the `wheel_separation` to put into `resq_sim/urdf_gen.py` (dict `P`). Rebuild is not needed with
`--symlink-install`; just relaunch. Repeat until the ratio is ~1.00.

## 6. Make the simulation match your real rover (edit `resq_sim/urdf_gen.py`, dict `P`)

| parameter | what to do |
|---|---|
| `chassis_mass`, `wheel_mass`, `arm_mass` | **weigh the real rover**; the defaults (2.4 kg total) are a guess |
| `wheel_effort` | stall torque per wheel after your gearbox (N·m) |
| `max_linear_vel` | real top speed |
| `wheel_mu`, `body_mu` | friction of your track rubber / printed body |
| `arm_limit`, `arm_effort` | stroke and force of your piston linkage |
| `camera_*`, `imu_xyz` | sensor placement and specs |

The COM and inertia of the body are measured from your STL (uniform density). If your real COM is lower/further
back because of the battery, shift it by editing `body_com_m` in `meshes/mesh_props.json`.

## 7. When you change the CAD

```bash
python3 src/resq_sim/tools/prepare_meshes.py /path/to/folder/with/your/STLs      # re-splits + decimates
python3 src/resq_sim/tools/validate_urdf.py                                       # offline sanity check
colcon build --symlink-install
```

## 8. How it is modelled (and its limits)

* **Tracks**: modelled as a skid-steer base: each side has a sprocket and an idler wheel (both driven, collision radius
  35.3 mm = your belt radius), plus a low-friction belt skid plate between them so the rover can ride over ledges
  like a real belt. Your solid belt STL is the visual. Individual `track_link` bodies are not simulated: a
  per-link belt is very slow and unstable in rigid-body engines, and for a smooth belt it behaves the same.
* **Lift unit**: each side's arm is a revolute joint at the pivot measured from `lift_piston_units_only_1.stl`, driven by a
  position controller. The actuator body/rod is drawn fixed (not telescoping) and the actuator force is not modelled
  – the joint is driven directly. From the CAD geometry, a fully lowered arm lifts the front wheels only about
  **30 mm** (check `arm_limit`); the 60 mm step on the rubble course is therefore a stress test.
* Collisions use simple boxes/cylinders (fast, stable); the huge CAD meshes are visual only.
* Forward is +X (the side the lift arms and camera point to).

## 9. Troubleshooting

| symptom | fix |
|---|---|
| Gazebo opens black / crashes in VM or WSL | `export LIBGL_ALWAYS_SOFTWARE=1`, or try `--render-engine ogre` in `gz_args` of the launch file |
| Robot invisible / "mesh not found" | `ros2 pkg prefix resq_sim` must work, and `install/resq_sim/share/resq_sim/meshes/body.stl` must exist |
| No `/camera/camera_info` | run `gz topic -l \| grep camera`, put the real name into `config/bridge.yaml` |
| Rover jitters or flies | lower `max_*_acc`, or `chassis_mass` too small for `wheel_effort`; try `<max_step_size>` 0.0005 in the world |
| Rover will not turn | raise `wheel_effort` or lower `wheel_mu`; then re-run calibration |
| Lift arms oscillate | lower `arm_p_gain` or raise `arm_d_gain` |
| Camera works only with GUI | headless needs `--headless-rendering` (already set when `gui:=false`) and an EGL GPU/driver |

## Other versions
* **ROS 2 Humble (Ubuntu 22.04)**: `sudo apt install ros-humble-ros-gzharmonic` and `export GZ_VERSION=harmonic` before building/launching. The package is unchanged.
* ROS 1 / Gazebo Classic are end-of-life and not supported by this package.
