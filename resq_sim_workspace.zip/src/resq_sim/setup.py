import os
from glob import glob
from setuptools import setup

pkg = 'resq_sim'
setup(
    name=pkg, version='0.1.0', packages=[pkg],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + pkg]),
        ('share/' + pkg, ['package.xml']),
        (os.path.join('share', pkg, 'launch'), glob('launch/*.py')),
        (os.path.join('share', pkg, 'config'), glob('config/*.yaml')),
        (os.path.join('share', pkg, 'rviz'), glob('rviz/*.rviz')),
        (os.path.join('share', pkg, 'worlds'), glob('worlds/*.sdf')),
        (os.path.join('share', pkg, 'meshes'), glob('meshes/*')),
    ],
    install_requires=['setuptools'], zip_safe=True,
    maintainer='RESQ-Sense', maintainer_email='architagupta271@gmail.com',
    description='RESQ-Sense rover Gazebo simulation', license='MIT',
    entry_points={'console_scripts': [
        'rover_keyboard = resq_sim.rover_keyboard:main',
        'calibrate_turn = resq_sim.calibrate_turn:main',
    ]},
)
