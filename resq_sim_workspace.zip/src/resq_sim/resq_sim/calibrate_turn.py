#!/usr/bin/env python3
"""Measures how well the rover really turns / drives vs. what was commanded, and tells you the
wheel_separation to put in resq_sim/urdf_gen.py.  Run on the flat_test world:

    ros2 launch resq_sim sim.launch.py world:=flat_test
    ros2 run resq_sim calibrate_turn            # optional:  --ros-args -p separation:=0.25
"""
import math, time
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from resq_sim.urdf_gen import P


def yaw_of(q):
    return math.atan2(2 * (q.w * q.z + q.x * q.y), 1 - 2 * (q.y * q.y + q.z * q.z))


class Cal(Node):
    def __init__(self):
        super().__init__('calibrate_turn')
        self.declare_parameter('separation', P['wheel_separation'])
        self.pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.sub = self.create_subscription(Odometry, '/ground_truth/odom', self.cb, 10)
        self.p = None

    def cb(self, m):
        self.p = (m.pose.pose.position.x, m.pose.pose.position.y, yaw_of(m.pose.pose.orientation))

    def wait_pose(self):
        while rclpy.ok() and self.p is None: rclpy.spin_once(self, timeout_sec=0.1)

    def run(self, v, w, secs, settle=1.0):
        """drive for secs; return mean (distance rate, yaw rate) after the settle time"""
        t0 = time.time(); a = None; b = None
        while rclpy.ok() and time.time() - t0 < secs:
            t = Twist(); t.linear.x = v; t.angular.z = w; self.pub.publish(t)
            rclpy.spin_once(self, timeout_sec=0.05)
            if self.p and time.time() - t0 > settle and a is None: a = (self.p, time.time())
            b = (self.p, time.time())
        self.pub.publish(Twist()); time.sleep(1.0); rclpy.spin_once(self, timeout_sec=0.1)
        (pa, ta), (pb, tb) = a, b; dt = tb - ta
        dyaw = math.atan2(math.sin(pb[2] - pa[2]), math.cos(pb[2] - pa[2]))
        return math.hypot(pb[0] - pa[0], pb[1] - pa[1]) / dt, dyaw / dt


def main():
    rclpy.init(); n = Cal(); n.wait_pose()
    S = n.get_parameter('separation').value
    print("straight test: commanding 0.20 m/s for 5 s ...")
    v, _ = n.run(0.2, 0.0, 5.0); print(f"  measured {v:.3f} m/s  (ratio {v/0.2:.2f})")
    # drive back so we don't leave the flat area
    n.run(-0.2, 0.0, 5.0)
    print("turn test: commanding 0.8 rad/s for 6 s ...")
    _, w = n.run(0.0, 0.8, 6.0); print(f"  measured {w:.3f} rad/s  (ratio {w/0.8:.2f})")
    if abs(w) > 1e-3:
        print(f"\nCurrent wheel_separation = {S:.3f} m")
        print(f"==> set wheel_separation = {S * 0.8 / abs(w):.3f}  in resq_sim/urdf_gen.py (P dict), rebuild, re-run to confirm.")
    n.destroy_node(); rclpy.shutdown()


if __name__ == '__main__':
    main()
