"""
Generates the RESQ-Sense rover URDF (with Gazebo plugins/sensors) from the measured CAD geometry.

All numbers in P below are SI units (metres, kg, seconds) unless noted.  Edit them here, or pass
overrides:   build_urdf(mesh_dir="file:///abs/path/meshes", chassis_mass=2.2, ...)

Frame convention (matches your CAD): base_link origin = chassis floor centre, +X forward, +Y left, +Z up.
"""
import json, math, os

# --------------------------------------------------------------------------- parameters
P = dict(
    # ---- masses (WEIGH YOUR REAL ROVER and edit these) ----
    chassis_mass=1.8,        # kg  body + electronics + battery + motors + the track belts
    wheel_mass=0.06,         # kg  each of the 4 wheels
    arm_mass=0.15,           # kg  each lift arm

    # ---- track / wheel geometry (measured from your STLs) ----
    wheel_radius=0.0353,     # m   = track outer radius
    wheel_x=0.065,           # m   wheel centres at x = +/- wheel_x  (idler front, sprocket rear)
    wheel_y=0.096,           # m   track centre line at y = +/- wheel_y
    wheel_z=0.024,           # m   axle height above chassis floor
    track_width=0.038,       # m
    ground_clearance_drop=0.0030,   # m  low-friction belt skid plate sits this much above the ground

    # ---- skid-steer calibration ----
    wheel_separation=0.25,   # m   EFFECTIVE track separation for turning. Geometric = 0.192; tracks
                             #     scrub when turning so the effective value is larger. Calibrate with
                             #     `ros2 run resq_sim calibrate_turn`.
    max_linear_vel=0.5,      # m/s
    max_angular_vel=2.0,     # rad/s
    max_linear_acc=2.0,      # m/s^2
    max_angular_acc=6.0,     # rad/s^2
    wheel_effort=1.0,        # N*m  per-wheel motor torque limit (stall torque after gearbox)
    wheel_mu=0.9,            # rubber track on ground
    body_mu=0.1,             # chassis + belt skid plates (slide over obstacles)

    # ---- lift arms (the "piston" mechanism) ----
    arm_pivot=(0.0501, 0.067, 0.0374),   # m   pivot at (x, +/-y, z), measured from the STL
    arm_tip=(0.0855, 0.0242),            # m   ball centre relative to pivot (dx, dz) at rest
    arm_ball_radius=0.008,
    arm_limit=(0.0, 1.75),   # rad  0 = as drawn in CAD (up/forward), + = tip swings DOWN to push the ground
    arm_effort=3.0,          # N*m
    arm_p_gain=8.0, arm_d_gain=0.3,      # position controller gains

    # ---- sensors ----
    camera_xyz=(0.107, 0.0, 0.032),      # the lens cylinder in your CAD
    camera_hfov=1.2, camera_w=640, camera_h=480, camera_hz=15,
    imu_xyz=(0.0, 0.0, 0.030), imu_hz=100,

    # ---- options ----
    show_track_shell=True,   # False hides the solid belt so you can see the wheels rotate
    gazebo_plugins=True,     # False gives a plain URDF for RViz/MoveIt only
    robot_name="resq_rover",
)

_here = os.path.dirname(os.path.abspath(__file__))


def _load_props(mesh_dir_fs):
    try:
        return json.load(open(os.path.join(mesh_dir_fs, "mesh_props.json")))
    except Exception:
        return None


def _f(v):
    return f"{v:.6g}"


def _inertial(m, com, I):
    """I = 3x3 nested list (kg m^2)"""
    return (f'<inertial><origin xyz="{_f(com[0])} {_f(com[1])} {_f(com[2])}" rpy="0 0 0"/>'
            f'<mass value="{_f(m)}"/>'
            f'<inertia ixx="{_f(I[0][0])}" ixy="{_f(I[0][1])}" ixz="{_f(I[0][2])}" '
            f'iyy="{_f(I[1][1])}" iyz="{_f(I[1][2])}" izz="{_f(I[2][2])}"/></inertial>')


def build_urdf(mesh_dir, **overrides):
    """mesh_dir: URI prefix of the meshes folder, e.g. 'file:///home/me/ws/install/resq_sim/share/resq_sim/meshes'"""
    p = dict(P); p.update(overrides)
    mesh_dir = mesh_dir.rstrip("/")
    fs_dir = mesh_dir[7:] if mesh_dir.startswith("file://") else os.path.join(_here, "..", "meshes")
    props = _load_props(fs_dir)
    mesh = lambda n: f'<mesh filename="{mesh_dir}/{n}" scale="0.001 0.001 0.001"/>'

    # ---- base inertia from the measured mesh (uniform density), scaled to the chosen mass
    if props:
        com = props["body_com_m"]; Ipk = props["body_inertia_per_kg"]
    else:                                            # fallback: solid box 0.208 x 0.150 x 0.067
        com = [0.004, 0.0, 0.04]
        Ipk = [[(0.15**2 + 0.067**2) / 12, 0, 0], [0, (0.208**2 + 0.067**2) / 12, 0], [0, 0, (0.208**2 + 0.15**2) / 12]]
    M = p["chassis_mass"]; Ib = [[M * x for x in r] for r in Ipk]

    r, w, hx, hy, hz = p["wheel_radius"], p["track_width"], p["wheel_x"], p["wheel_y"], p["wheel_z"]
    wm = p["wheel_mass"]
    Iax = 0.5 * wm * r * r; Itr = wm * (3 * r * r + w * w) / 12
    Iw = [[Itr, 0, 0], [0, Iax, 0], [0, 0, Itr]]

    # ---- belt skid plate (low friction box between the wheels, only touches on ledges)
    z_bot = hz - r + p["ground_clearance_drop"]; z_top = hz + r
    plate = dict(size=(2 * hx, w, z_top - z_bot), z=(z_top + z_bot) / 2)

    o = []
    A = o.append
    A('<?xml version="1.0"?>')
    A(f'<robot name="{p["robot_name"]}">')
    for n, c in dict(body="0.55 0.58 0.63 1", belt="0.10 0.10 0.11 1", sprocket="0.95 0.78 0.10 1",
                     idler="0.95 0.55 0.10 1", arm="0.85 0.25 0.15 1", piston="0.15 0.45 0.85 1",
                     sensor="0.05 0.05 0.05 1").items():
        A(f'<material name="{n}"><color rgba="{c}"/></material>')

    # ================= base_link
    A('<link name="base_link">')
    A(_inertial(M, com, Ib))
    A(f'<visual><geometry>{mesh("body.stl")}</geometry><material name="body"/></visual>')
    A(f'<visual><geometry>{mesh("piston_fixed.stl")}</geometry><material name="piston"/></visual>')
    if p["show_track_shell"]:
        for s in ("left", "right"):
            A(f'<visual><geometry>{mesh(f"track_{s}.stl")}</geometry><material name="belt"/></visual>')
    # collisions (primitives: fast and stable; the visual meshes are far too detailed to collide with)
    A('<collision name="chassis"><origin xyz="0.004 0 0.033"/><geometry><box size="0.208 0.150 0.066"/></geometry></collision>')
    A('<collision name="turret"><origin xyz="0.037 0 0.0895"/><geometry><cylinder radius="0.035" length="0.045"/></geometry></collision>')
    for s, sg in (("left", 1), ("right", -1)):
        A(f'<collision name="belt_plate_{s}"><origin xyz="0 {_f(sg*hy)} {_f(plate["z"])}"/>'
          f'<geometry><box size="{_f(plate["size"][0])} {_f(plate["size"][1])} {_f(plate["size"][2])}"/></geometry></collision>')
    A('</link>')

    # ================= wheels (sprocket rear, idler front; both driven so the belt moves as one)
    for s, sg in (("left", 1), ("right", -1)):
        for kind, x in (("sprocket", -hx), ("idler", hx)):
            n = f"{s}_{kind}"
            A(f'<link name="{n}_link">{_inertial(wm, (0, 0, 0), Iw)}'
              f'<visual><geometry>{mesh(kind + ".stl")}</geometry><material name="{kind}"/></visual>'
              f'<collision><origin rpy="{_f(math.pi/2)} 0 0"/><geometry><cylinder radius="{_f(r)}" length="{_f(w)}"/></geometry></collision>'
              f'</link>')
            A(f'<joint name="{n}_joint" type="continuous"><parent link="base_link"/><child link="{n}_link"/>'
              f'<origin xyz="{_f(x)} {_f(sg*hy)} {_f(hz)}"/><axis xyz="0 1 0"/>'
              f'<limit effort="{_f(p["wheel_effort"])}" velocity="40"/><dynamics damping="0.005" friction="0.0"/></joint>')

    # ================= lift arms
    px, py, pz = p["arm_pivot"]; dx, dz = p["arm_tip"]
    L = math.hypot(dx, dz); alpha = math.atan2(dz, dx); am = p["arm_mass"]
    # thin rod of length L along its own x-axis (tilted up by alpha): Ixx small, Iyy = Izz = m L^2 / 12
    Il = am * L * L / 12 + 1e-6; Ia0 = max(am * (0.012**2 + 0.014**2) / 12, 2e-5)
    c, s_ = math.cos(alpha), math.sin(alpha)
    Ia = [[Ia0 * c * c + Il * s_ * s_, 0, (Ia0 - Il) * s_ * c],   # I = Ia0 n n^T + Il (E - n n^T), n = (cos a, 0, sin a)
          [0, Il, 0],
          [(Ia0 - Il) * s_ * c, 0, Ia0 * s_ * s_ + Il * c * c]]
    lo, hi = p["arm_limit"]
    for s, sg in (("left", 1), ("right", -1)):
        n = f"{s}_lift_arm"
        A(f'<link name="{n}_link">{_inertial(am, (dx/2, 0, dz/2), Ia)}')
        A(f'<visual><origin xyz="{_f(-px)} {_f(-sg*py)} {_f(-pz)}"/><geometry>{mesh(f"arm_{s}.stl")}</geometry><material name="arm"/></visual>')
        A(f'<collision name="bar"><origin xyz="{_f(dx/2)} 0 {_f(dz/2)}" rpy="0 {_f(-alpha)} 0"/>'
          f'<geometry><box size="{_f(L)} 0.012 0.014"/></geometry></collision>')
        A(f'<collision name="ball"><origin xyz="{_f(dx)} 0 {_f(dz)}"/><geometry><sphere radius="{_f(p["arm_ball_radius"])}"/></geometry></collision>')
        A('</link>')
        A(f'<joint name="{n}_joint" type="revolute"><parent link="base_link"/><child link="{n}_link"/>'
          f'<origin xyz="{_f(px)} {_f(sg*py)} {_f(pz)}"/><axis xyz="0 1 0"/>'
          f'<limit lower="{_f(lo)}" upper="{_f(hi)}" effort="{_f(p["arm_effort"])}" velocity="1.0"/>'
          f'<dynamics damping="0.05" friction="0.01"/></joint>')

    # ================= sensors
    cx, cy, cz = p["camera_xyz"]
    A(f'<link name="camera_link"><inertial><mass value="0.02"/><inertia ixx="1e-6" ixy="0" ixz="0" iyy="1e-6" iyz="0" izz="1e-6"/></inertial></link>')
    A(f'<joint name="camera_joint" type="fixed"><parent link="base_link"/><child link="camera_link"/><origin xyz="{cx} {cy} {cz}"/></joint>')
    ix, iy, iz = p["imu_xyz"]
    A(f'<link name="imu_link"><inertial><mass value="0.005"/><inertia ixx="1e-7" ixy="0" ixz="0" iyy="1e-7" iyz="0" izz="1e-7"/></inertial></link>')
    A(f'<joint name="imu_joint" type="fixed"><parent link="base_link"/><child link="imu_link"/><origin xyz="{ix} {iy} {iz}"/></joint>')

    if p["gazebo_plugins"]:
        # ---------- friction (applies to every collision of the link)
        A(f'<gazebo reference="base_link"><mu1>{p["body_mu"]}</mu1><mu2>{p["body_mu"]}</mu2></gazebo>')
        for s in ("left", "right"):
            for k in ("sprocket", "idler"):
                A(f'<gazebo reference="{s}_{k}_link"><mu1>{p["wheel_mu"]}</mu1><mu2>{p["wheel_mu"]}</mu2></gazebo>')
            A(f'<gazebo reference="{s}_lift_arm_link"><mu1>0.6</mu1><mu2>0.6</mu2></gazebo>')

        # ---------- sensors
        A(f'''<gazebo reference="camera_link"><sensor name="front_camera" type="camera">
  <always_on>true</always_on><update_rate>{p["camera_hz"]}</update_rate><topic>camera/image_raw</topic>
  <gz_frame_id>camera_link</gz_frame_id>
  <camera><horizontal_fov>{p["camera_hfov"]}</horizontal_fov>
    <image><width>{p["camera_w"]}</width><height>{p["camera_h"]}</height><format>R8G8B8</format></image>
    <clip><near>0.03</near><far>40</far></clip>
    <noise><type>gaussian</type><mean>0.0</mean><stddev>0.007</stddev></noise></camera>
</sensor></gazebo>''')
        A(f'''<gazebo reference="imu_link"><sensor name="imu_sensor" type="imu">
  <always_on>true</always_on><update_rate>{p["imu_hz"]}</update_rate><topic>imu/data</topic>
  <gz_frame_id>imu_link</gz_frame_id>
  <imu>
    <angular_velocity>
      <x><noise type="gaussian"><mean>0</mean><stddev>0.005</stddev></noise></x>
      <y><noise type="gaussian"><mean>0</mean><stddev>0.005</stddev></noise></y>
      <z><noise type="gaussian"><mean>0</mean><stddev>0.005</stddev></noise></z>
    </angular_velocity>
    <linear_acceleration>
      <x><noise type="gaussian"><mean>0</mean><stddev>0.04</stddev></noise></x>
      <y><noise type="gaussian"><mean>0</mean><stddev>0.04</stddev></noise></y>
      <z><noise type="gaussian"><mean>0</mean><stddev>0.04</stddev></noise></z>
    </linear_acceleration>
  </imu>
</sensor></gazebo>''')

        # ---------- model plugins
        lefts = "".join(f"<left_joint>left_{k}_joint</left_joint>" for k in ("sprocket", "idler"))
        rights = "".join(f"<right_joint>right_{k}_joint</right_joint>" for k in ("sprocket", "idler"))
        A(f'''<gazebo>
  <plugin filename="gz-sim-diff-drive-system" name="gz::sim::systems::DiffDrive">
    {lefts}{rights}
    <wheel_separation>{p["wheel_separation"]}</wheel_separation>
    <wheel_radius>{p["wheel_radius"]}</wheel_radius>
    <frame_id>odom</frame_id><child_frame_id>base_link</child_frame_id>
    <odom_publish_frequency>50</odom_publish_frequency>
    <max_linear_velocity>{p["max_linear_vel"]}</max_linear_velocity><min_linear_velocity>{-p["max_linear_vel"]}</min_linear_velocity>
    <max_angular_velocity>{p["max_angular_vel"]}</max_angular_velocity><min_angular_velocity>{-p["max_angular_vel"]}</min_angular_velocity>
    <max_linear_acceleration>{p["max_linear_acc"]}</max_linear_acceleration><min_linear_acceleration>{-p["max_linear_acc"]}</min_linear_acceleration>
    <max_angular_acceleration>{p["max_angular_acc"]}</max_angular_acceleration><min_angular_acceleration>{-p["max_angular_acc"]}</min_angular_acceleration>
  </plugin>
  <plugin filename="gz-sim-joint-state-publisher-system" name="gz::sim::systems::JointStatePublisher"/>
  <plugin filename="gz-sim-odometry-publisher-system" name="gz::sim::systems::OdometryPublisher">
    <odom_frame>world</odom_frame><robot_base_frame>base_link</robot_base_frame>
    <odom_topic>/ground_truth/odom</odom_topic><tf_topic>/ground_truth/tf</tf_topic>
    <odom_publish_frequency>30</odom_publish_frequency><dimensions>3</dimensions>
  </plugin>''')
        for s in ("left", "right"):
            A(f'''  <plugin filename="gz-sim-joint-position-controller-system" name="gz::sim::systems::JointPositionController">
    <joint_name>{s}_lift_arm_joint</joint_name><topic>/lift/cmd_pos</topic>
    <p_gain>{p["arm_p_gain"]}</p_gain><d_gain>{p["arm_d_gain"]}</d_gain><i_gain>0.0</i_gain>
    <cmd_min>{-p["arm_effort"]}</cmd_min><cmd_max>{p["arm_effort"]}</cmd_max>
  </plugin>''')
        A('</gazebo>')
    A('</robot>')
    return "\n".join(o)


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="print the rover URDF")
    ap.add_argument("--mesh-dir", default="file://" + os.path.abspath(os.path.join(_here, "..", "meshes")))
    ap.add_argument("--no-gz", action="store_true", help="omit Gazebo plugins/sensors (RViz-only URDF)")
    a = ap.parse_args()
    print(build_urdf(a.mesh_dir, gazebo_plugins=not a.no_gz))
