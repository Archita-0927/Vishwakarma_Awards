#!/usr/bin/env python3
"""Regenerates worlds/flat_test.sdf, rubble.sdf and climb_test.sdf  (python3 tools/gen_worlds.py)"""
import math, os, random
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'worlds')

HEADER = """<?xml version="1.0"?>
<sdf version="1.9">
<world name="resq_world">
  <physics name="1ms" type="ignored"><max_step_size>0.001</max_step_size><real_time_factor>1.0</real_time_factor></physics>
  <plugin filename="gz-sim-physics-system" name="gz::sim::systems::Physics"/>
  <plugin filename="gz-sim-user-commands-system" name="gz::sim::systems::UserCommands"/>
  <plugin filename="gz-sim-scene-broadcaster-system" name="gz::sim::systems::SceneBroadcaster"/>
  <plugin filename="gz-sim-sensors-system" name="gz::sim::systems::Sensors"><render_engine>ogre2</render_engine></plugin>
  <plugin filename="gz-sim-imu-system" name="gz::sim::systems::Imu"/>
  <gravity>0 0 -9.81</gravity>
  <scene><ambient>0.45 0.45 0.45 1</ambient><background>0.62 0.72 0.85 1</background><shadows>true</shadows></scene>
  <light type="directional" name="sun">
    <cast_shadows>true</cast_shadows><pose>0 0 10 0 0 0</pose><diffuse>0.9 0.9 0.85 1</diffuse><specular>0.2 0.2 0.2 1</specular>
    <direction>-0.5 0.3 -0.9</direction>
  </light>
  <model name="ground"><static>true</static><link name="link">
    <collision name="c"><geometry><plane><normal>0 0 1</normal><size>200 200</size></plane></geometry>
      <surface><friction><ode><mu>1.0</mu><mu2>1.0</mu2></ode></friction></surface></collision>
    <visual name="v"><geometry><plane><normal>0 0 1</normal><size>200 200</size></plane></geometry>
      <material><ambient>0.55 0.53 0.5 1</ambient><diffuse>0.55 0.53 0.5 1</diffuse></material></visual>
  </link></model>
"""
FOOTER = "</world>\n</sdf>\n"
_n = [0]

def _model(shape, pose, color, collide=True, mu=0.8, name=None):
    _n[0] += 1; name = name or f"obj{_n[0]}"
    col = (f'<collision name="c"><geometry>{shape}</geometry><surface><friction><ode><mu>{mu}</mu><mu2>{mu}</mu2></ode></friction></surface></collision>'
           if collide else '')
    pose = tuple(pose) + (0.0,) * (6 - len(pose))      # SDF needs x y z roll pitch yaw (6 values)
    px = " ".join(f"{v:.4f}" for v in pose)
    return (f'<model name="{name}"><static>true</static><pose>{px}</pose><link name="l">{col}'
            f'<visual name="v"><geometry>{shape}</geometry><material><ambient>{color}</ambient><diffuse>{color}</diffuse></material></visual>'
            f'</link></model>\n')

def box(size, pose, color="0.5 0.5 0.5 1", **k):
    return _model(f"<box><size>{size[0]:.4f} {size[1]:.4f} {size[2]:.4f}</size></box>", pose, color, **k)
def cyl(r, l, pose, color="0.5 0.5 0.5 1", **k):
    return _model(f"<cylinder><radius>{r}</radius><length>{l}</length></cylinder>", pose, color, **k)
def sph(r, pose, color, **k):
    return _model(f"<sphere><radius>{r}</radius></sphere>", pose, color, **k)
def caps(r, l, pose, color, **k):
    return _model(f"<capsule><radius>{r}</radius><length>{l}</length></capsule>", pose, color, **k)

def markers():
    s = ""
    for i in range(1, 16):   # 1 m distance markers (visual only)
        s += box((0.03, 1.2, 0.002), (i, 0, 0.001), "1 1 1 1" if i % 5 else "0.9 0.2 0.1 1", collide=False, name=f"mark{i}")
    return s

def ramp(x0, length, deg, down=False, h0=0.0, width=0.8, t=0.04, name=None):
    """plank whose top surface runs from (x0, h0) along the slope; down=True slopes downward in +x"""
    th = math.radians(deg); sg = -1 if down else 1
    ux, uz = math.cos(th), sg * math.sin(th)          # unit vector along the surface
    nx, nz = -sg * math.sin(th), math.cos(th)          # upward normal
    cx = x0 + length / 2 * ux - t / 2 * nx
    cz = h0 + length / 2 * uz - t / 2 * nz
    return box((length, width, t), (cx, 0, cz, 0, -sg * th, 0), "0.45 0.42 0.38 1", name=name)

def flat():
    return HEADER + markers() + FOOTER

def rubble():
    rnd = random.Random(7); s = HEADER + markers()
    # 1) steps: 20 / 40 / 60 mm  (wheel radius is 35 mm -> the 40 and 60 mm steps need the lift arms)
    for i, h in enumerate((0.020, 0.040, 0.060)):
        s += box((0.30, 0.9, h), (1.5 + 1.2 * i, 0, h / 2), "0.62 0.58 0.5 1", name=f"step_{int(h*1000)}mm")
    # 2) 15 degree ramp up, 0.6 m platform, ramp down
    L, th = 0.6, math.radians(15); h = L * math.sin(th); xe = 5.2 + L * math.cos(th)
    s += ramp(5.2, L, 15, name="ramp_up")
    s += box((0.6, 0.8, h), (xe + 0.3, 0, h / 2), "0.45 0.42 0.38 1", name="platform")
    s += ramp(xe + 0.6, L, 15, down=True, h0=h, name="ramp_down")
    # 3) rubble field x = 7 .. 10.5 (random tilted blocks, bricks and pipes)
    for i in range(70):
        x = rnd.uniform(7.0, 10.5); y = rnd.uniform(-0.55, 0.55)
        sx, sy, sz = rnd.uniform(0.04, 0.12), rnd.uniform(0.04, 0.12), rnd.uniform(0.02, 0.06)
        roll, pitch, yaw = rnd.uniform(-0.35, 0.35), rnd.uniform(-0.35, 0.35), rnd.uniform(0, math.pi)
        g = rnd.uniform(0.35, 0.65)
        s += box((sx, sy, sz), (x, y, sz * 0.35, roll, pitch, yaw), f"{g:.2f} {g*0.95:.2f} {g*0.9:.2f} 1", name=f"rubble{i}")
    for i in range(6):   # rebar / pipes
        x = rnd.uniform(7.2, 10.3); y = rnd.uniform(-0.4, 0.4)
        s += cyl(0.012, 0.5, (x, y, 0.014, math.pi / 2, 0, rnd.uniform(0, math.pi)), "0.35 0.3 0.28 1", name=f"pipe{i}")
    # 4) collapsed slab leaning over the 'survivor'
    s += box((0.12, 0.12, 0.10), (11.6, -0.30, 0.05), "0.6 0.6 0.6 1", name="support_a")
    s += box((0.12, 0.12, 0.10), (11.6, 0.30, 0.05), "0.6 0.6 0.6 1", name="support_b")
    s += box((0.9, 0.9, 0.04), (11.9, 0, 0.12, 0, 0.18, 0), "0.5 0.5 0.52 1", name="collapsed_slab")
    # 5) the survivor dummy (lying on its back, head towards the rover)
    s += caps(0.05, 0.38, (12.0, 0, 0.05, 0, math.pi / 2, 0), "0.85 0.62 0.5 1", name="survivor_torso")
    s += sph(0.065, (11.72, 0, 0.065), "0.9 0.7 0.58 1", name="survivor_head")
    s += caps(0.03, 0.30, (12.35, 0.07, 0.03, 0, math.pi / 2, 0.15), "0.2 0.25 0.5 1", name="survivor_leg_l")
    s += caps(0.03, 0.30, (12.35, -0.07, 0.03, 0, math.pi / 2, -0.15), "0.2 0.25 0.5 1", name="survivor_leg_r")
    return s + FOOTER

def climb_test():
    """obstacles close to the start so the auto-climb can be watched straight away"""
    s = HEADER + markers()
    for x, h in ((0.9, 0.015), (2.2, 0.025), (3.5, 0.035)):          # steps 15 / 25 / 35 mm, 0.5 m deep, 1 m wide
        s += box((0.5, 1.0, h), (x + 0.25, 0, h / 2), "0.62 0.58 0.5 1", name=f"step_{int(h*1000)}mm")
    s += cyl(0.015, 1.0, (4.9, 0, 0.015, math.pi / 2, 0, 0), "0.45 0.3 0.25 1", name="pipe_30mm")   # round pipe, 30 mm dia
    s += box((0.3, 1.0, 0.10), (6.3, 0, 0.05), "0.75 0.25 0.2 1", name="wall_100mm_impassable")  # too tall: it must give up
    return s + FOOTER

if __name__ == '__main__':
    os.makedirs(OUT, exist_ok=True)
    open(os.path.join(OUT, 'flat_test.sdf'), 'w').write(flat())
    open(os.path.join(OUT, 'rubble.sdf'), 'w').write(rubble())
    open(os.path.join(OUT, 'climb_test.sdf'), 'w').write(climb_test())
    print("wrote flat_test.sdf, rubble.sdf, climb_test.sdf")
