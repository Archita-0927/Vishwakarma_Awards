#!/usr/bin/env python3
"""
Turn the raw CAD STLs (millimetres, huge triangle counts) into simulation-ready meshes.

Usage:
    python3 tools/prepare_meshes.py <folder_with_your_STLs> [--cell 2.5]

Re-run this whenever you re-export your CAD.  Needs only numpy + scipy.

Outputs (into ../meshes):
    body.stl            rover_assembly minus the two track shells, decimated
    track_left.stl / track_right.stl   track belts taken from the assembly
    sprocket.stl / idler.stl           wheels, re-centred, axle along +Y
    arm_left.stl / arm_right.stl       lift arms (rotate about the pivot)
    piston_fixed.stl                   non-moving parts of the lift units
    mesh_props.json                    COM / inertia (per unit mass) measured from the body mesh
All meshes stay in MILLIMETRES, the URDF applies scale 0.001.
"""
import sys, os, glob, json, argparse
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components

# ---------------------------------------------------------------- STL io
def load_stl(path):
    d = open(path, 'rb').read()
    n = int(np.frombuffer(d[80:84], '<u4')[0])
    if 84 + 50 * n != len(d):
        raise SystemExit(f"{path}: not a binary STL (ASCII STL? re-export as binary)")
    dt = np.dtype([('n', '<f4', 3), ('v', '<f4', (3, 3)), ('a', '<u2')])
    return np.frombuffer(d, dt, count=n, offset=84)['v'].astype(np.float64)

def write_stl(path, t):
    t = t.astype('<f4')
    n = np.cross(t[:, 1] - t[:, 0], t[:, 2] - t[:, 0])
    l = np.linalg.norm(n, axis=1, keepdims=True); n = n / np.where(l == 0, 1, l)
    dt = np.dtype([('n', '<f4', 3), ('v', '<f4', (3, 3)), ('a', '<u2')])
    a = np.zeros(len(t), dt); a['n'] = n; a['v'] = t
    with open(path, 'wb') as f:
        f.write(b'resq_sim mesh'.ljust(80, b' ')); f.write(np.uint32(len(t)).tobytes()); f.write(a.tobytes())

# ---------------------------------------------------------------- geometry helpers
def components(t):
    q = np.round(t.reshape(-1, 3) * 100).astype(np.int64)
    _, inv = np.unique(q, axis=0, return_inverse=True)
    inv = inv.reshape(-1, 3); n = inv.max() + 1
    r = np.concatenate([inv[:, 0], inv[:, 1]]); c = np.concatenate([inv[:, 1], inv[:, 2]])
    _, lab = connected_components(coo_matrix((np.ones(len(r)), (r, c)), shape=(n, n)), directed=False)
    return lab[inv[:, 0]]

def decimate(t, cell):
    """vertex-clustering decimation: fast, keeps overall shape, drops tiny detail"""
    p = t.reshape(-1, 3)
    key = np.floor(p / cell).astype(np.int64)
    uk, inv = np.unique(key, axis=0, return_inverse=True); inv = inv.ravel()
    sums = np.zeros((len(uk), 3)); np.add.at(sums, inv, p)
    rep = sums / np.bincount(inv, minlength=len(uk))[:, None]
    idx = inv.reshape(-1, 3)
    ok = (idx[:, 0] != idx[:, 1]) & (idx[:, 1] != idx[:, 2]) & (idx[:, 0] != idx[:, 2])
    idx = idx[ok]
    _, u = np.unique(np.sort(idx, axis=1), axis=0, return_index=True)
    return rep[idx[u]]

def mass_props(t):
    """volume, centroid, inertia tensor about centroid per unit density (mm units)"""
    a, b, c = t[:, 0], t[:, 1], t[:, 2]
    v6 = np.einsum('ij,ij->i', a, np.cross(b, c)); vol = v6.sum() / 6
    cen = ((a + b + c) / 4 * v6[:, None]).sum(0) / 6 / vol
    s = a + b + c; C = np.zeros((3, 3))
    for i in range(3):
        for j in range(3):
            C[i, j] = (v6 * (a[:, i]*a[:, j] + b[:, i]*b[:, j] + c[:, i]*c[:, j] + s[:, i]*s[:, j])).sum() / 120
    Cc = C - vol * np.outer(cen, cen)
    return vol, cen, np.trace(Cc) * np.eye(3) - Cc

def find(folder, key):
    hits = sorted(glob.glob(os.path.join(folder, f'*{key}*.stl')))
    if not hits: raise SystemExit(f"cannot find an STL containing '{key}' in {folder}")
    return hits[0]

def bbox(t):
    p = t.reshape(-1, 3); return p.min(0), p.max(0)

# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('stl_dir'); ap.add_argument('--cell', type=float, default=2.5,
                    help='decimation grid in mm (bigger = lighter mesh), default 2.5')
    ap.add_argument('--out', default=os.path.join(os.path.dirname(__file__), '..', 'meshes'))
    args = ap.parse_args(); os.makedirs(args.out, exist_ok=True)
    out = lambda n: os.path.join(args.out, n)

    # ---- assembly -> body + track shells
    asm = load_stl(find(args.stl_dir, 'rover_assembly'))
    lab = components(asm)
    body_parts, shells = [], {}
    for i in np.unique(lab):
        tri = asm[lab == i]; lo, hi = bbox(tri)
        # a track shell = a long (x>150 mm) slab ~38 mm wide sitting outside the chassis wall (|y|>76)
        if (hi[0] - lo[0]) > 150 and 30 < (hi[1] - lo[1]) < 45 and abs(lo[1] + hi[1]) / 2 > 76:
            shells['left' if (lo[1] + hi[1]) > 0 else 'right'] = tri
        else:
            body_parts.append(tri)
    if len(shells) != 2: raise SystemExit("could not find both track shells in the assembly STL")
    body = np.concatenate(body_parts)
    print(f"assembly {len(asm)} tris -> body {len(body)} tris (+2 track shells)")
    body_d = decimate(body, args.cell); write_stl(out('body.stl'), body_d)
    print(f"  body decimated to {len(body_d)} tris")
    for s, tri in shells.items(): write_stl(out(f'track_{s}.stl'), tri)

    # track geometry measured from the shells
    lo, hi = bbox(shells['left'])
    track = dict(length=hi[0]-lo[0], y_min=lo[1], y_max=hi[1], z_min=lo[2], z_max=hi[2])
    radius = (hi[2] - lo[2]) / 2; zc = (hi[2] + lo[2]) / 2
    track.update(radius=radius, z_center=zc, x_center_offset=(hi[0]-lo[0])/2 - radius, y_center=(lo[1]+hi[1])/2)

    # ---- wheels: centre them and turn the axle from +Z to +Y
    def wheel(key, name):
        t = load_stl(find(args.stl_dir, key)); lo, hi = bbox(t)
        c = np.array([(lo[0]+hi[0])/2, (lo[1]+hi[1])/2, (lo[2]+hi[2])/2]); t = t - c
        t = np.stack([t[..., 0], t[..., 2], -t[..., 1]], -1)       # Rx(-90deg): z -> y
        write_stl(out(name), t); return dict(diameter=hi[0]-lo[0], width=hi[2]-lo[2])
    wheel_info = wheel('drive_sprocket', 'sprocket.stl'); wheel('idler_wheel', 'idler.stl')

    # ---- lift unit: arms vs fixed parts
    pis = load_stl(find(args.stl_dir, 'piston')); pl = components(pis)
    arms = {'left': [], 'right': []}; fixed = []
    for i in np.unique(pl):
        tri = pis[pl == i]; lo, hi = bbox(tri); c = (lo + hi) / 2
        is_arm = c[0] > 43 and c[2] > 30 and len(tri) >= 100       # forward of the pivot, above axle height
        if is_arm: arms['left' if c[1] > 0 else 'right'].append(tri)
        else: fixed.append(tri)
    for s in arms: write_stl(out(f'arm_{s}.stl'), np.concatenate(arms[s]))
    write_stl(out('piston_fixed.stl'), np.concatenate(fixed))
    ball = np.concatenate(arms['left']); lo, hi = bbox(ball)
    print(f"lift arm (left) bbox {lo.round(1)} .. {hi.round(1)}")

    # ---- body mass properties (unit density) -> per-unit-mass inertia in m^2
    vol, cen, I = mass_props(body)
    props = dict(body_com_m=(cen / 1000).tolist(),
                 body_inertia_per_kg=(I / vol * 1e-6).tolist(),
                 body_bbox_mm=[bbox(body)[0].tolist(), bbox(body)[1].tolist()],
                 track_mm=track, wheel_mm=wheel_info)
    json.dump(props, open(out('mesh_props.json'), 'w'), indent=2)
    print(json.dumps(props, indent=1)[:900])

if __name__ == '__main__':
    main()
