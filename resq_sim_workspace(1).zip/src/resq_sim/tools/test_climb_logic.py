#!/usr/bin/env python3
"""Offline test of the climbing state machine against a crude 1-D 'rover + obstacle' model (no ROS/Gazebo needed)."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from resq_sim.climb_logic import ClimbFSM

def run(arm_needed, secs=40, wall_x=1.0, wall_len=0.3, cmd=0.25, tilt=0.0, sensor=False, verbose=False):
    f = ClimbFSM(); x = 0.0; speed = 0.0; dt = 0.05; hist = []; arm = 0.0
    for i in range(int(secs / dt)):
        rng = (wall_x - 0.05 - x) if sensor and x < wall_x else None            # sensor sits at the front edge
        if rng is not None and rng < 0: rng = 0.0
        v, w, a_t, st = f.update(dt, cmd, 0.0, speed, tilt, 0.0, rng)
        arm += max(-0.8 * dt, min(0.8 * dt, a_t - arm))                 # arm follows its target
        blocked = (wall_x - 0.05 < x < wall_x + 0.02) and arm < arm_needed and v > 0
        target = 0.0 if blocked else v
        speed += (target - speed) * min(1.0, 8 * dt)                     # first-order drive response
        x += speed * dt
        if not hist or hist[-1][1] != st: hist.append((round(i * dt, 1), st, round(x, 2), round(arm, 2)))
        if st == 'APPROACH' and 'first_approach' not in f.__dict__: f.first_approach = (x, arm)
    return f, x, hist

ok = True
def check(name, cond):
    global ok; ok &= bool(cond); print(("PASS " if cond else "FAIL ") + name)

f, x, h = run(arm_needed=0.9)
print("  timeline:", h)
check("climbs an obstacle that needs arm>=0.9 and ends past it", x > 1.6)
check("returns to DRIVE with arms retracted", f.state == "DRIVE" and f.arm < 0.05)
f, x, h = run(arm_needed=0.0)
check("free path: arms never deploy", all(s[1] == "DRIVE" for s in h) and x > 5)
f, x, h = run(arm_needed=2.5)
print("  timeline:", h)
check("impossible obstacle: retries then FAILED, stopped, arms up", f.state == "FAILED" and f.arm < 0.05 and x < 1.05)
f, x, h = run(arm_needed=0.9, tilt=1.0)
check("tilt beyond limit -> FAILED immediately", h[-1][1] == "FAILED" and x < 0.1)
f, x, h = run(arm_needed=0.9, sensor=True)
print("  timeline (with front sensor):", h)
check("with sensor: sees it and enters APPROACH (slows, pre-lowers the arms) before touching it",
      hasattr(f, 'first_approach') and any(s[1] == 'APPROACH' for s in h) and
      next(s for s in h if s[1] == 'APPROACH')[2] < 0.97)
check("with sensor: still climbs and ends past the obstacle, arms up", x > 1.6 and f.state == "DRIVE" and f.arm < 0.05)
f, x, h = run(arm_needed=2.5, sensor=True)
check("with sensor: impassable obstacle -> gives up safely (FAILED, stopped, arms up)", f.state == "FAILED" and f.arm < 0.05 and x < 1.05)
f = ClimbFSM(); out = f.update(0.05, 0.0, 0.0, 0.0, 0, 0)
check("no command -> no motion, no arm", out[:3] == (0.0, 0.0, 0.0))
print("ALL OK" if ok else "SOME TESTS FAILED"); sys.exit(0 if ok else 1)
