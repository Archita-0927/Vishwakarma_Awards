#!/usr/bin/env python3
"""Offline sanity check of the generated URDF: tree structure, mesh files, physical inertias, plugin joints."""
import sys, os, math
import numpy as np
from lxml import etree
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from resq_sim.urdf_gen import build_urdf

mesh_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'meshes'))
xml = build_urdf("file://" + mesh_dir)
root = etree.fromstring(xml.encode())
errs = []
links = {l.get('name'): l for l in root.findall('link')}
joints = root.findall('joint')
children = {j.find('child').get('link') for j in joints}
roots = [n for n in links if n not in children]
if roots != ['base_link']: errs.append(f"root links = {roots}")
for j in joints:
    for t in ('parent', 'child'):
        if j.find(t).get('link') not in links: errs.append(f"joint {j.get('name')} {t} missing")
names = [j.get('name') for j in joints]
if len(set(names)) != len(names): errs.append("duplicate joint names")
# meshes exist and are in mm-scale
for m in root.iter('mesh'):
    f = m.get('filename').replace('file://', '')
    if not os.path.isfile(f): errs.append(f"missing mesh {f}")
# inertia checks
total = 0
for n, l in links.items():
    i = l.find('inertial'); m = float(i.find('mass').get('value')); total += m
    a = i.find('inertia'); g = lambda k: float(a.get(k))
    I = np.array([[g('ixx'), g('ixy'), g('ixz')], [g('ixy'), g('iyy'), g('iyz')], [g('ixz'), g('iyz'), g('izz')]])
    ev = np.linalg.eigvalsh(I)
    if ev.min() <= 0: errs.append(f"{n}: inertia not positive definite {ev}")
    if ev[2] > ev[0] + ev[1] + 1e-12: errs.append(f"{n}: violates triangle inequality {ev}")
# plugin joints exist
jn = set(names)
for tag in ('left_joint', 'right_joint', 'joint_name'):
    for e in root.iter(tag):
        if e.text not in jn: errs.append(f"plugin refers to unknown joint {e.text}")
print(f"links={len(links)} joints={len(joints)} total mass={total:.3f} kg")
for j in joints: print(f"  {j.get('type'):10s} {j.get('name'):26s} {j.find('parent').get('link')} -> {j.find('child').get('link')}")
print("ERRORS:" if errs else "OK - no problems found"); [print(" -", e) for e in errs]
sys.exit(1 if errs else 0)
