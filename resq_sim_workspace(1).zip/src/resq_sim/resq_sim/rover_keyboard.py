#!/usr/bin/env python3
"""Keyboard teleop for the RESQ rover: drive + lift arms.
   w/s forward/back   a/d turn left/right   x or space stop
   r / f  raise / lower lift arms (0 .. 1.75 rad)   t  arms to rest   q quit
"""
import sys, termios, tty, select
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import Float64

HELP = __doc__


class Teleop(Node):
    def __init__(self):
        super().__init__('rover_keyboard')
        self.cmd = self.create_publisher(Twist, '/cmd_vel_raw', 10)
        self.lift = self.create_publisher(Float64, '/lift/manual', 10)
        self.declare_parameter('lin', 0.25); self.declare_parameter('ang', 1.0)
        self.v = 0.0; self.w = 0.0; self.arm = 0.0

    def send(self):
        t = Twist(); t.linear.x = self.v; t.angular.z = self.w; self.cmd.publish(t)
        self.lift.publish(Float64(data=self.arm))


def main():
    rclpy.init(); n = Teleop(); print(HELP)
    fd = sys.stdin.fileno(); old = termios.tcgetattr(fd); tty.setcbreak(fd)
    lin = n.get_parameter('lin').value; ang = n.get_parameter('ang').value
    try:
        while rclpy.ok():
            if select.select([sys.stdin], [], [], 0.1)[0]:
                k = sys.stdin.read(1).lower()
                if k == 'w': n.v, n.w = lin, 0.0
                elif k == 's': n.v, n.w = -lin, 0.0
                elif k == 'a': n.v, n.w = 0.0, ang
                elif k == 'd': n.v, n.w = 0.0, -ang
                elif k in ('x', ' '): n.v = n.w = 0.0
                elif k == 'r': n.arm = min(1.75, n.arm + 0.1)
                elif k == 'f': n.arm = max(0.0, n.arm - 0.1)
                elif k == 't': n.arm = 0.0
                elif k == 'q': break
                print(f"\rv={n.v:+.2f} w={n.w:+.2f} arm={n.arm:.1f}   ", end='', flush=True)
            n.send()
    finally:
        n.v = n.w = 0.0; n.send()
        termios.tcsetattr(fd, termios.TCSADRAIN, old); n.destroy_node(); rclpy.shutdown()


if __name__ == '__main__':
    main()
