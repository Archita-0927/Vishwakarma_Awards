"""
Obstacle-climbing state machine (pure Python, no ROS) - tested offline by tools/test_climb_logic.py.

Idea (needs no extra hardware):  if the operator/navigation asks for forward motion but the rover is not moving,
something is blocking it.  Then:
    DRIVE   -> normal pass-through of the commanded velocity
    APPROACH-> (needs the front range sensor) an obstacle is seen within `obstacle_dist`: slow to creep speed and
               pre-lower the arms to `arm_ready`, just above the ground, before touching it
    DEPLOY  -> creep forward while the lift arms swing down and push the ground; this raises the front
               until the tracks bite on top of the obstacle (rover starts moving again)
    CRAWL   -> keep creeping with the arms down until the whole rover has travelled `climb_distance`
               (front over the edge, rear following).  If it stalls again -> DEPLOY continues
    RETRACT -> arms swing back up while still creeping, then back to DRIVE
    BACKOFF -> arms reached their limit and it still did not move: reverse a little, retry harder
    FAILED  -> too many tries, or the rover is dangerously tilted: stop, arms up, wait for a fresh command

Pitch/roll (from the IMU) are only used as a tip-over safety.
"""

DRIVE, APPROACH, DEPLOY, CRAWL, RETRACT, BACKOFF, FAILED = "DRIVE", "APPROACH", "DEPLOY", "CRAWL", "RETRACT", "BACKOFF", "FAILED"


def _ramp(cur, tgt, rate, dt):
    step = rate * dt
    return cur + max(-step, min(step, tgt - cur))


class ClimbFSM:
    def __init__(self, **kw):
        p = dict(
            v_min=0.05,          # m/s   command above this counts as "wants to go forward"
            stall_ratio=0.4,     # measured speed < ratio * commanded speed  => blocked
            stall_time=0.6,      # s     must be blocked this long
            v_crawl=0.08,        # m/s   creep speed while climbing
            arm_max=1.6,         # rad   furthest the arms are driven (joint limit is 1.75)
            deploy_rate=0.35,    # rad/s arm lowering speed
            retract_rate=0.8,    # rad/s arm raising speed
            hold_time=1.0,       # s     wait at full arm extension before giving up
            climb_distance=0.30, # m     travel with arms down before retracting
            backoff_dist=0.12,   # m
            max_tries=3,
            obstacle_dist=0.12,  # m     front sensor sees something closer than this -> APPROACH
            clear_dist=0.25,     # m     sensor reading above this (or nothing) = the way ahead is clear
            arm_ready=0.60,      # rad   arm angle held while approaching (ground contact starts at ~0.75)
            pitch_max=0.80, roll_max=0.80,   # rad  tip-over safety
        )
        p.update(kw); self.p = p; self.reset()

    def reset(self):
        self.state = DRIVE; self.arm = 0.0
        self.t_block = self.t_move = self.t_hold = self.dist = self.t_idle = self.t_clear = 0.0
        self.tries = 0; self.reason = ""

    def update(self, dt, cmd_v, cmd_w, speed, pitch, roll, front_range=None):
        """returns (v_out, w_out, arm_target, state).  speed = measured forward speed magnitude (m/s);
        front_range = nearest obstacle distance ahead in metres, or None (no sensor / nothing seen)"""
        p = self.p
        if self.state != FAILED and (abs(pitch) > p["pitch_max"] or abs(roll) > p["roll_max"]):
            self.state = FAILED; self.reason = f"tilt pitch={pitch:.2f} roll={roll:.2f}"; self.t_idle = 0.0
        want = cmd_v > p["v_min"]
        v, w = cmd_v, cmd_w
        boost = 1.0 + 0.3 * self.tries            # push a little harder on every retry

        if self.state == DRIVE:
            self.arm = _ramp(self.arm, 0.0, p["retract_rate"], dt)
            blocked = want and abs(cmd_w) < 0.3 and speed < p["stall_ratio"] * cmd_v
            self.t_block = self.t_block + dt if blocked else 0.0
            seen = want and abs(cmd_w) < 0.3 and front_range is not None and front_range < p["obstacle_dist"]
            if seen:
                self.state = APPROACH; self.t_clear = 0.0; self.t_block = 0.0; self.reason = f"obstacle at {front_range:.2f} m"
            elif self.t_block >= p["stall_time"]:
                self.state = DEPLOY; self.t_move = self.t_hold = 0.0; self.reason = "blocked"

        elif self.state == APPROACH:
            if not want:
                self.state = DRIVE; self.t_block = 0.0; v = w = 0.0
            else:
                v, w = p["v_crawl"] * boost, 0.0
                self.arm = _ramp(self.arm, p["arm_ready"], p["deploy_rate"] * 2, dt)
                blocked = speed < p["stall_ratio"] * p["v_crawl"]
                self.t_block = self.t_block + dt if blocked else 0.0
                clear = front_range is None or front_range > p["clear_dist"]
                self.t_clear = self.t_clear + dt if clear else 0.0
                if self.t_block >= 0.5 and self.arm >= p["arm_ready"] - 0.02:
                    self.state = DEPLOY; self.t_move = self.t_hold = 0.0; self.reason = "touched obstacle"
                elif self.t_clear >= 1.0 and speed > 0.5 * p["v_crawl"]:
                    self.state = CRAWL; self.dist = 0.0; self.t_block = 0.0     # obstacle is now under the front tracks

        elif self.state == DEPLOY:
            if not want:                                  # operator gave up
                self.state = DRIVE; self.t_block = 0.0; v = w = 0.0
            else:
                v, w = p["v_crawl"] * boost, 0.0
                self.arm = _ramp(self.arm, p["arm_max"], p["deploy_rate"], dt)
                self.t_move = self.t_move + dt if speed > 0.5 * p["v_crawl"] else 0.0
                if self.t_move > 0.3:
                    self.state = CRAWL; self.dist = 0.0; self.t_block = 0.0
                elif self.arm >= p["arm_max"] - 1e-3:
                    self.t_hold += dt
                    if self.t_hold >= p["hold_time"]:
                        self.tries += 1; self.dist = 0.0; self.state = BACKOFF; self.reason = f"try {self.tries} failed"

        elif self.state == CRAWL:
            if not want:
                v = w = 0.0                               # operator stopped: hold position, arms stay
            else:
                v, w = p["v_crawl"] * boost, 0.0
                self.dist += speed * dt
                self.t_block = self.t_block + dt if speed < 0.3 * p["v_crawl"] else 0.0
                if self.t_block > 1.0:
                    self.state = DEPLOY; self.t_move = self.t_hold = 0.0       # stalled again: keep lowering arms
                elif self.dist >= p["climb_distance"]:
                    self.state = RETRACT

        elif self.state == RETRACT:
            v, w = (p["v_crawl"] if want else 0.0), 0.0
            self.arm = _ramp(self.arm, 0.0, p["retract_rate"], dt)
            if self.arm <= 0.02:
                self.state = DRIVE; self.tries = 0; self.t_block = 0.0

        elif self.state == BACKOFF:
            v, w = -0.10, 0.0
            self.arm = _ramp(self.arm, 0.0, p["retract_rate"], dt)
            self.dist += abs(speed) * dt
            if self.dist >= p["backoff_dist"]:
                if self.tries >= p["max_tries"]:
                    self.state = FAILED; self.reason = "gave up after retries"; self.t_idle = 0.0
                else:
                    self.state = DRIVE; self.t_block = 0.0

        if self.state == FAILED:
            v = w = 0.0
            self.arm = _ramp(self.arm, 0.0, p["retract_rate"], dt)
            idle = abs(cmd_v) < 0.01 and abs(cmd_w) < 0.01
            self.t_idle = self.t_idle + dt if idle else 0.0
            if self.t_idle > 1.5 and abs(pitch) < p["pitch_max"] and abs(roll) < p["roll_max"]:
                self.reset()                              # operator released the stick: ready again
        return v, w, self.arm, self.state
