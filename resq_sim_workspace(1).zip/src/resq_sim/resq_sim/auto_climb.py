#!/usr/bin/env python3
"""
Automatic obstacle climbing for the RESQ rover.  Sits between the operator/navigation and the drive:

    /cmd_vel_raw  ->  [auto_climb]  ->  /cmd_vel          (drive)
    /lift/manual  ->  [auto_climb]  ->  /lift/cmd_pos     (arms)
    reads /imu/data (tilt), /front_range/scan (obstacle ahead) and a speed source (default /ground_truth/odom)
    publishes /climb/status (String)

Parameters:  enabled (true; false = plain pass-through),  speed_topic,  plus every ClimbFSM parameter
e.g.  ros2 run resq_sim auto_climb --ros-args -p v_crawl:=0.1 -p arm_max:=1.7
NOTE: in simulation the true speed comes from /ground_truth/odom.  On the real rover feed speed_topic with
something that measures real ground speed (encoders + IMU fusion, optical flow, visual odometry); encoder
speed alone cannot detect a stalled/slipping track.
"""
import math, time
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Imu, LaserScan
from std_msgs.msg import Float64, String
from resq_sim.climb_logic import ClimbFSM


class AutoClimb(Node):
    def __init__(self):
        super().__init__('auto_climb')
        self.fsm = ClimbFSM(); defaults = self.fsm.p
        for k, v in defaults.items(): self.declare_parameter(k, v)
        self.declare_parameter('enabled', True); self.declare_parameter('speed_topic', '/ground_truth/odom')
        self.pub_cmd = self.create_publisher(Twist, '/cmd_vel', 10)
        self.pub_arm = self.create_publisher(Float64, '/lift/cmd_pos', 10)
        self.pub_st = self.create_publisher(String, '/climb/status', 10)
        self.create_subscription(Twist, '/cmd_vel_raw', self.on_cmd, 10)
        self.create_subscription(Float64, '/lift/manual', self.on_manual, 10)
        self.create_subscription(Imu, '/imu/data', self.on_imu, 10)
        self.create_subscription(LaserScan, '/front_range/scan', self.on_scan, 10)
        self.range = None; self.t_range = 0.0
        self.create_subscription(Odometry, self.get_parameter('speed_topic').value, self.on_speed, 10)
        self.cmd = (0.0, 0.0); self.t_cmd = 0.0; self.speed = 0.0; self.pitch = 0.0; self.roll = 0.0
        self.manual = 0.0; self.t_manual = 0.0; self.last = None; self.last_state = None
        self.dt = 0.05; self.create_timer(self.dt, self.tick)

    def on_cmd(self, m): self.cmd = (m.linear.x, m.angular.z); self.t_cmd = time.time()
    def on_manual(self, m): self.manual = float(m.data); self.t_manual = time.time()
    def on_speed(self, m):
        l = m.twist.twist.linear; self.speed = math.sqrt(l.x * l.x + l.y * l.y + l.z * l.z)

    def on_scan(self, m):   # nearest valid reading of the centre rays (ignores the outer ones)
        n = len(m.ranges); c = range(n // 2 - 1, n // 2 + 2) if n >= 3 else range(n)
        vals = [m.ranges[i] for i in c if math.isfinite(m.ranges[i]) and m.range_min < m.ranges[i] < m.range_max]
        self.range = min(vals) if vals else None; self.t_range = time.time()

    def on_imu(self, m):   # tilt from the gravity vector (low-pass filtered); nose-up positive
        a = m.linear_acceleration; g = max(math.sqrt(a.x**2 + a.y**2 + a.z**2), 1e-3)
        pitch = math.asin(max(-1.0, min(1.0, a.x / g))); roll = math.atan2(a.y, a.z)
        self.pitch += 0.1 * (pitch - self.pitch); self.roll += 0.1 * (roll - self.roll)

    def tick(self):
        now = time.time()
        cv, cw = self.cmd if now - self.t_cmd < 0.5 else (0.0, 0.0)     # command timeout
        if not self.get_parameter('enabled').value:
            self.fsm.reset(); v, w, arm, st = cv, cw, (self.manual if now - self.t_manual < 1.0 else 0.0), 'DISABLED'
        else:
            for k in self.fsm.p: self.fsm.p[k] = self.get_parameter(k).value
            v, w, arm, st = self.fsm.update(self.dt, cv, cw, self.speed, self.pitch, self.roll,
                                                self.range if now - self.t_range < 0.5 else None)
            if st == 'DRIVE' and now - self.t_manual < 1.0 and self.manual > arm:
                arm = self.manual                                         # manual arm override while driving normally
        t = Twist(); t.linear.x = float(v); t.angular.z = float(w); self.pub_cmd.publish(t)
        self.pub_arm.publish(Float64(data=float(arm)))
        if st != self.last_state:
            self.get_logger().info(f"climb state: {st}  {self.fsm.reason if st in ('APPROACH','DEPLOY','BACKOFF','FAILED') else ''}")
            self.last_state = st
        self.pub_st.publish(String(data=st))


def main():
    rclpy.init(); n = AutoClimb()
    try: rclpy.spin(n)
    except KeyboardInterrupt: pass
    finally: n.destroy_node(); rclpy.shutdown()


if __name__ == '__main__':
    main()
