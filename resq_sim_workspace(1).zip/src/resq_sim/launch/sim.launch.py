"""
ros2 launch resq_sim sim.launch.py [world:=rubble|flat_test|/abs/path.sdf] [gui:=true|false]
                                   [rviz:=true|false] [track_shell:=true|false] [x:= y:= z:= yaw:=]
"""
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, OpaqueFunction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

from resq_sim.urdf_gen import build_urdf


def _setup(context, *args, **kwargs):
    pkg = get_package_share_directory('resq_sim')
    gz_sim = get_package_share_directory('ros_gz_sim')
    arg = lambda n: LaunchConfiguration(n).perform(context)

    world = arg('world')
    if not os.path.isabs(world):
        world = os.path.join(pkg, 'worlds', world if world.endswith('.sdf') else world + '.sdf')
    gui = arg('gui').lower() == 'true'
    # -r run immediately, -s server only (no window), --headless-rendering lets cameras work without a display
    gz_args = f'-r {world}' if gui else f'-r -s --headless-rendering {world}'

    urdf = build_urdf('file://' + os.path.join(pkg, 'meshes'),
                      show_track_shell=arg('track_shell').lower() == 'true')

    actions = [
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(os.path.join(gz_sim, 'launch', 'gz_sim.launch.py')),
            launch_arguments={'gz_args': gz_args, 'on_exit_shutdown': 'true'}.items()),

        Node(package='robot_state_publisher', executable='robot_state_publisher', output='screen',
             parameters=[{'robot_description': urdf, 'use_sim_time': True}]),

        Node(package='ros_gz_sim', executable='create', output='screen',
             arguments=['-name', 'resq_rover', '-topic', 'robot_description',
                        '-x', arg('x'), '-y', arg('y'), '-z', arg('z'), '-Y', arg('yaw')]),

        Node(package='ros_gz_bridge', executable='parameter_bridge', output='screen',
             parameters=[{'config_file': os.path.join(pkg, 'config', 'bridge.yaml'), 'use_sim_time': True}]),
    ]
    # automatic obstacle climbing: /cmd_vel_raw -> /cmd_vel and /lift/manual -> /lift/cmd_pos
    actions.append(Node(package='resq_sim', executable='auto_climb', output='screen',
                        parameters=[{'enabled': arg('auto_climb').lower() == 'true', 'use_sim_time': True}]))
    if arg('rviz').lower() == 'true':
        actions.append(Node(package='rviz2', executable='rviz2', output='screen',
                            arguments=['-d', os.path.join(pkg, 'rviz', 'resq.rviz')],
                            parameters=[{'use_sim_time': True}]))
    return actions


def generate_launch_description():
    d = lambda n, v, h='': DeclareLaunchArgument(n, default_value=v, description=h)
    return LaunchDescription([
        d('world', 'climb_test', 'climb_test | rubble | flat_test | absolute path to an .sdf'),
        d('gui', 'true', 'false = headless (server only)'),
        d('rviz', 'true', 'start RViz2'),
        d('auto_climb', 'true', 'automatic obstacle climbing with the lift arms'),
        d('track_shell', 'true', 'false hides the solid belt so the wheels are visible'),
        d('x', '0.0'), d('y', '0.0'), d('z', '0.02'), d('yaw', '0.0'),
        OpaqueFunction(function=_setup),
    ])
